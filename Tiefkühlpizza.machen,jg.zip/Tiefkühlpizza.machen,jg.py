
from time import sleep

zutaten= "Tiefkühlpizza"
geschirr= "Teller"
geräte= ["Backofen", "Tiefkühlschrank"]
temperatur="kalt"

print(f"{geräte[0]} wurde angeschaltet und heizt vor.")

while temperatur == "kalt":
    sleep(60)
    temperatur = "heiß"

print(f"{geräte[0]} ist vorgeheizt.")
print(f"{zutaten} aus Tiefkühlschrank nehmen.")
print(f"{zutaten} aus Verpackung nehmen.")
print(f"Öffne {geräte[0]}")
print(f"{zutaten} in {geräte[0]} legen.")
print(f"Schließe {geräte[0]}")
print(f"{zutaten} wird zubereitet, fertig in 1 min.")

zaehler = 60

while True:
    print(f"Noch {zaehler} Sekunden.")
    sleep(1)
    zaehler = zaehler -1
    if zaehler > 0:
        continue

    else :
        print("Fertig.")
        break

print(f"{geräte[0]} ausschalten.")
print(f"Öffne {geräte[0]} ")
print(f"{zutaten} aus {geräte[0]} nehmen.")
print(f" {zutaten} auf {geschirr} legen.")
print("Fertig!")

